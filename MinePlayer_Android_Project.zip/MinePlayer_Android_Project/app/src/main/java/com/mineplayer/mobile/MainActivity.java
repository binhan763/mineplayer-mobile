package com.mineplayer.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;

public class MainActivity extends Activity {
    int bg=Color.rgb(11,16,32), panel=Color.rgb(22,33,54), line=Color.rgb(43,59,83);
    int blue=Color.rgb(100,177,255), white=Color.rgb(238,245,255), muted=Color.rgb(158,177,204);
    LinearLayout root, body, tabs;
    TextView log, sellResult, chatResult, payResult, accountResult;
    EditText sellCmd, chatInput, recipient, amount, interval, budget, host, version;
    Spinner sellMode, protocol, unit;
    LinearLayout sellPane, chatPane, payPane, accountPane;
    TextView tabSell, tabChat, tabPay, tabAccount;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this); body.setOrientation(1); body.setPadding(dp(16),dp(14),dp(16),dp(24));
        root.addView(header());
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        showTab("sell");
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,dp(4),0,dp(4));return t;
    }
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    View header(){
        LinearLayout h=column();h.setPadding(dp(18),dp(18),dp(18),dp(12));h.setBackgroundColor(bg);
        h.addView(text("MINEPLAYER  MOBILE",21,white,true));
        h.addView(text("EXPERIMENTAL PROTOTYPE  •  OFFLINE DEMO",10,blue,true));
        h.addView(text("● Demo offline     •     Bedrock / Java: chưa kết nối",12,muted,false));
        return h;
    }
    void base(){
        body.removeAllViews();
        tabs=row(); tabs.setPadding(0,0,0,dp(12));
        tabSell=tab("Auto Sell","sell");tabChat=tab("Custom Chat","chat");tabPay=tab("Auto Pay","pay");tabAccount=tab("Tài khoản","account");
        tabs.addView(tabSell,new LinearLayout.LayoutParams(0,dp(44),1));
        tabs.addView(tabChat,new LinearLayout.LayoutParams(0,dp(44),1));
        tabs.addView(tabPay,new LinearLayout.LayoutParams(0,dp(44),1));
        tabs.addView(tabAccount,new LinearLayout.LayoutParams(0,dp(44),1));
        body.addView(tabs);
    }
    TextView tab(String s,String id){
        TextView t=text(s,11,white,true);t.setGravity(Gravity.CENTER);t.setBackground(round(line,10));t.setOnClickListener(v->showTab(id));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-1);p.setMargins(dp(2),0,dp(2),0);t.setLayoutParams(p);return t;
    }
    android.graphics.drawable.GradientDrawable round(int c,int r){
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));d.setStroke(dp(1),line);return d;
    }
    LinearLayout card(String title,String desc){
        LinearLayout c=column();c.setPadding(dp(15),dp(13),dp(15),dp(15));c.setBackground(round(panel,15));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(12));c.setLayoutParams(cp);
        c.addView(text(title,16,white,true));c.addView(text(desc,12,muted,false));body.addView(c);return c;
    }
    void label(LinearLayout c,String s){c.addView(text(s,12,muted,true));}
    EditText edit(LinearLayout c,String hint,String value,int inputType){
        EditText e=new EditText(this);e.setSingleLine(inputType!=0);e.setTextSize(14);e.setTextColor(white);e.setHintTextColor(muted);
        e.setHint(hint);if(value!=null)e.setText(value);e.setInputType(inputType);e.setPadding(dp(10),dp(7),dp(10),dp(7));e.setBackground(round(bg,9));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(4),0,dp(8));c.addView(e,p);return e;
    }
    Button button(LinearLayout c,String title,Runnable action){
        Button b=new Button(this);b.setText(title);b.setTextColor(Color.rgb(5,15,30));b.setTextSize(13);b.setAllCaps(false);b.setBackground(round(blue,10));
        b.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(7),0,0);c.addView(b,p);return b;
    }
    TextView result(LinearLayout c,String initial){
        TextView t=text(initial,12,muted,false);t.setPadding(dp(10),dp(10),dp(10),dp(10));t.setBackground(round(bg,9));c.addView(t);return t;
    }
    Spinner spinner(LinearLayout c,String[] options){
        Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,options));
        c.addView(s);return s;
    }
    void showTab(String id){
        base();
        if(id.equals("sell")){
            LinearLayout c=card("🛒 Sell Assistant","Bản thử nghiệm giao diện. Không tự gửi lệnh lên máy chủ.");
            label(c,"Lệnh bán");sellCmd=edit(c,"/sell","/sell",0);
            label(c,"Chế độ");sellMode=spinner(c,new String[]{"Hướng dẫn thủ công","Kiểm thử GUI giả lập"});
            button(c,"Mô phỏng quy trình bán",()->{sellResult.setText("Mô phỏng: "+sellCmd.getText()+". Không có lệnh nào được gửi.");addLog("Sell Assistant demo; no network command.");});
            sellResult=result(c,"Chưa chạy thử. Mở game và thao tác thủ công nếu muốn.");
            LinearLayout l=card("📋 Nhật ký hoạt động","Nhật ký trong phiên ứng dụng.");
            log=text("[MinePlayer] Prototype đã khởi động.\n[Network] Offline demo — chưa có kết nối Minecraft.",11,Color.rgb(159,223,199),false);
            l.addView(log);button(l,"Xóa nhật ký",()->log.setText("Nhật ký đã xóa."));
        } else if(id.equals("chat")){
            LinearLayout c=card("💬 Custom Chat","Nhập nội dung để xem trước hoặc sao chép. Chưa gửi đến server.");
            label(c,"Tin nhắn (tối đa 256 ký tự)");chatInput=edit(c,"Nhập tin nhắn...","",0);chatInput.setSingleLine(false);chatInput.setMinLines(3);
            button(c,"Xem trước tin nhắn",()->chatResult.setText(chatInput.getText().toString().isEmpty()?"Hãy nhập tin nhắn trước.":"Xem trước: "+chatInput.getText()));
            button(c,"Sao chép tin nhắn",()->{String s=chatInput.getText().toString();if(!s.isEmpty()){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("Minecraft chat",s));chatResult.setText("Đã sao chép. Tin nhắn chưa được gửi tới server.");}else chatResult.setText("Hãy nhập tin nhắn trước.");});
            chatResult=result(c,"Tin nhắn chưa được gửi.");
        } else if(id.equals("pay")){
            LinearLayout c=card("🔁 Auto Pay Scheduler","Cấu hình demo. Không thực hiện thanh toán thật.");
            label(c,"Người nhận");recipient=edit(c,"Minecraft username","",0);
            label(c,"Số tiền mỗi lần");amount=edit(c,"1000","1000",2);
            label(c,"Chu kỳ");interval=edit(c,"60","60",2);
            label(c,"Đơn vị");unit=spinner(c,new String[]{"Phút","Giây","Giờ"});
            label(c,"Ngân sách tối đa");budget=edit(c,"5000","5000",2);
            button(c,"Lưu cấu hình demo",()->{try{int a=Integer.parseInt(amount.getText().toString()),i=Integer.parseInt(interval.getText().toString()),b=Integer.parseInt(budget.getText().toString());if(recipient.getText().toString().trim().isEmpty()||a<1||i<1||b<a)throw new Exception();payResult.setText("Đã lưu cấu hình demo. Không có khoản thanh toán nào được gửi.");}catch(Exception e){payResult.setText("Kiểm tra người nhận, số tiền, chu kỳ và ngân sách.");}});
            payResult=result(c,"Scheduler đang tắt.");
            button(c,"Dừng scheduler demo",()->payResult.setText("Scheduler demo đã dừng; không có giao dịch thật."));
        } else {
            LinearLayout c=card("👤 Kết nối tài khoản","Khung thử nghiệm. Không nhập mật khẩu hoặc token tại đây.");
            label(c,"Giao thức mục tiêu");protocol=spinner(c,new String[]{"Chưa chọn","Bedrock","Java Edition"});
            label(c,"Địa chỉ máy chủ");host=edit(c,"Server host","",0);
            label(c,"Phiên bản Minecraft");version=edit(c,"Phiên bản đang dùng","",0);
            button(c,"Lưu lựa chọn thử nghiệm",()->accountResult.setText("Đã lưu lựa chọn demo: "+protocol.getSelectedItem()+". Chưa có kết nối mạng."));
            accountResult=result(c,"Chưa có kết nối mạng.");
        }
        body.addView(text("Prototype 0.1 • Không có kết nối Minecraft • Chưa phải bot giao dịch thật",10,muted,false));
    }
    void addLog(String s){if(log!=null)log.append("\n"+s);}
}
