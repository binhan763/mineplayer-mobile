MinePlayer Android Project — Prototype 0.1

This is a native Android Studio project, not a prebuilt APK.
It contains a native offline demo UI for Sell Assistant, Custom Chat, Auto Pay config, and protocol selection.

Build APK:
1. Open this folder in Android Studio.
2. Use JDK 17 and Android SDK Platform 35.
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK should be at app/build/outputs/apk/debug/app-debug.apk.

No Minecraft network protocol, Microsoft/Xbox login, real Auto Sell, real Auto Pay, or anti-cheat evasion is implemented. Do not enter account passwords or tokens.
